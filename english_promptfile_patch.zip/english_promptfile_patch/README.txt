This is an English patch for the prompt.
Overwrite the files inside the folder below to switch your prompts to the English version.

C:\Users\%userprofile%\.mulmollaa\promptfiles